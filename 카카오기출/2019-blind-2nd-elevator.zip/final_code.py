import requests
# 문제 1 : 1754 > 817
# 문제 2 : 3112 > 1978

url = 'http://localhost:8000'


def start(user, problem, count):
    uri = url + '/start' + '/' + user + '/' + str(problem) + '/' + str(count)
    return requests.post(uri).json()


def oncalls(token):
    uri = url + '/oncalls'
    return requests.get(uri, headers={'X-Auth-Token': token}).json()


def action(token, cmds):
    uri = url + '/action'
    return requests.post(uri, headers={'X-Auth-Token': token}, json={'commands': cmds}).json()


def elev_al(tmp):
    board = check(tmp['calls'])
    board_p = pas_ck(tmp['elevators'][0]['passengers'])
    elev = tmp['elevators']
    ret = [None, None]

    # elev 0
    if elev[0]['passengers'] == []:
        if elev[0]['status'] == 'OPENED':
            if board[elev[0]['floor']]['up'] == []:
                ret[0] = {'elevator_id': 0, 'command': 'CLOSE'}
            else:
                if len(board[elev[0]['floor']]['up']) > 8:
                    a = len(board[elev[0]['floor']]['up'])
                    ent_id = board[elev[0]['floor']]['up'][a - 8:]
                else:
                    ent_id = board[elev[0]['floor']]['up']
                ret[0] = {'elevator_id': 0,
                          'command': 'ENTER', 'call_ids': ent_id}
        elif board['up'] == []:
            ret[0] = {'elevator_id': 0, 'command': 'STOP'}
        else:
            if elev[0]['floor'] > board['up'][0][1]:
                if elev[0]['status'] == 'UPWARD':
                    ret[0] = {'elevator_id': 0, 'command': 'STOP'}
                else:
                    ret[0] = {'elevator_id': 0, 'command': 'DOWN'}
            elif elev[0]['floor'] < board['up'][0][1]:
                if elev[0]['status'] == 'DOWNWARD':
                    ret[0] = {'elevator_id': 0, 'command': 'STOP'}
                else:
                    ret[0] = {'elevator_id': 0, 'command': 'UP'}
            else:
                if elev[0]['status'] == 'STOPPED':
                    ret[0] = {'elevator_id': 0, 'command': 'OPEN'}
                elif elev[0]['status'] != 'STOPPED':
                    ret[0] = {'elevator_id': 0, 'command': 'STOP'}
    else:
        emp = 8 - len(elev[0]['passengers'])
        if elev[0]['status'] == 'OPENED':
            if board_p[elev[0]['floor']] != []:
                ex_id = board_p[elev[0]['floor']]
                ret[0] = {'elevator_id': 0,
                          'command': 'EXIT', 'call_ids': ex_id}
            elif board[elev[0]['floor']]['up'] != [] and emp != 0:
                if len(board[elev[0]['floor']]['up']) > emp:
                    a = len(board[elev[0]['floor']]['up'])
                    ent_id = board[elev[0]['floor']]['up'][a - emp:]
                else:
                    ent_id = board[elev[0]['floor']]['up']
                ret[0] = {'elevator_id': 0,
                          'command': 'ENTER', 'call_ids': ent_id}
            else:
                ret[0] = {'elevator_id': 0, 'command': 'CLOSE'}
        elif elev[0]['status'] == 'STOPPED':
            if board_p[elev[0]['floor']] != [] or (board[elev[0]['floor']]['up'] != [] and emp != 0):
                ret[0] = {'elevator_id': 0, 'command': 'OPEN'}
            elif board_p[elev[0]['floor']] == []:
                ret[0] = {'elevator_id': 0, 'command': 'UP'}
        else:
            if board_p[elev[0]['floor']] != [] or (board[elev[0]['floor']]['up'] != [] and emp != 0):
                ret[0] = {'elevator_id': 0, 'command': 'STOP'}
            else:
                if elev[0]['status'] == 'UPWARD':
                    ret[0] = {'elevator_id': 0, 'command': 'UP'}
                elif elev[0]['status'] == 'DOWNWARD':
                    ret[0] = {'elevator_id': 0, 'command': 'DOWN'}

    # elev 1

    board_p = pas_ck(tmp['elevators'][1]['passengers'])

    if elev[1]['passengers'] == []:
        if elev[1]['status'] == 'OPENED':
            if board[elev[1]['floor']]['down'] == []:
                ret[1] = {'elevator_id': 1, 'command': 'CLOSE'}
            else:
                if len(board[elev[1]['floor']]['down']) > 8:
                    a = len(board[elev[1]['floor']]['down'])
                    ent_id = board[elev[1]['floor']]['down'][a - 8:]
                else:
                    ent_id = board[elev[1]['floor']]['down']
                ret[1] = {'elevator_id': 1,
                          'command': 'ENTER', 'call_ids': ent_id}
        elif board['down'] == []:
            ret[1] = {'elevator_id': 1, 'command': 'STOP'}
        else:
            if elev[1]['floor'] > board['down'][0][1]:
                if elev[1]['status'] == 'UPWARD':
                    ret[1] = {'elevator_id': 1, 'command': 'STOP'}
                else:
                    ret[1] = {'elevator_id': 1, 'command': 'DOWN'}
            elif elev[1]['floor'] < board['down'][0][1]:
                if elev[1]['status'] == 'DOWNWARD':
                    ret[1] = {'elevator_id': 1, 'command': 'STOP'}
                else:
                    ret[1] = {'elevator_id': 1, 'command': 'UP'}
            else:
                if elev[1]['status'] == 'STOPPED':
                    ret[1] = {'elevator_id': 1, 'command': 'OPEN'}
                elif elev[1]['status'] != 'STOPPED':
                    ret[1] = {'elevator_id': 1, 'command': 'STOP'}
    else:
        emp = 8 - len(elev[1]['passengers'])
        if elev[1]['status'] == 'OPENED':
            if board_p[elev[1]['floor']] != []:
                ex_id = board_p[elev[1]['floor']]
                ret[1] = {'elevator_id': 1,
                          'command': 'EXIT', 'call_ids': ex_id}
            elif board[elev[1]['floor']]['down'] != [] and emp != 0:
                if len(board[elev[1]['floor']]['down']) > emp:
                    a = len(board[elev[1]['floor']]['down'])
                    ent_id = board[elev[1]['floor']]['down'][a - emp:]
                else:
                    ent_id = board[elev[1]['floor']]['down']
                ret[1] = {'elevator_id': 1,
                          'command': 'ENTER', 'call_ids': ent_id}
            else:
                ret[1] = {'elevator_id': 1, 'command': 'CLOSE'}
        elif elev[1]['status'] == 'STOPPED':
            if board_p[elev[1]['floor']] != [] or (board[elev[1]['floor']]['down'] != [] and emp != 0):
                ret[1] = {'elevator_id': 1, 'command': 'OPEN'}
            elif board_p[elev[1]['floor']] == []:
                ret[1] = {'elevator_id': 1, 'command': 'DOWN'}
        else:
            if board_p[elev[1]['floor']] != [] or (board[elev[1]['floor']]['down'] != [] and emp != 0):
                ret[1] = {'elevator_id': 1, 'command': 'STOP'}
            else:
                if elev[1]['status'] == 'UPWARD':
                    ret[1] = {'elevator_id': 1, 'command': 'UP'}
                elif elev[1]['status'] == 'DOWNWARD':
                    ret[1] = {'elevator_id': 1, 'command': 'DOWN'}
    return ret


def check(calls):
    board = {'up': [], 'down': []}
    for f in range(1, 26):
        board[f] = {'up': [], 'down': []}
    for c in calls:
        if c['start'] - c['end'] < 0:
            board['up'].append((c['id'], c['start'], c['end']))
            board[c['start']]['up'].append(c['id'])
        else:
            board['down'].append((c['id'], c['start'], c['end']))
            board[c['start']]['down'].append(c['id'])
    board['up'].sort(key=lambda x: (x[1], -x[2]))
    board['down'].sort(key=lambda x: (x[1], -x[2]), reverse=True)
    return board


def pas_ck(calls):
    board = {}
    for f in range(1, 26):
        board[f] = []
    for c in calls:
        board[c['end']].append(c['id'])
    return board


def p0_simulator():
    user = 'tester'
    problem = 1
    count = 2

    ret = start(user, problem, count)
    token = ret['token']
    print('Token for %s is %s' % (user, token))
    while True:
        tmp = oncalls(token)
        if tmp['is_end']:
            break
        act = elev_al(tmp)
        action(token, act)
    return


if __name__ == '__main__':
    p0_simulator()
